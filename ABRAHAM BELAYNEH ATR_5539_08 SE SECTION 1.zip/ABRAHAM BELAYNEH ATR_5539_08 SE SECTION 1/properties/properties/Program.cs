﻿using System;



public class Student
{
        private int _id;
        private string _Name;
        private int _passMark = 50;

        public int GetPassMark()
        {
            return this._passMark;
        }

        public void SetName(string Name)
        {
            if(string.IsNullOrEmpty(Name))
            {
                throw new Exception("Name cannot be null or empty");
            }
            this._Name = Name;
        }

        public string GetName()
        {
            if(string.IsNullOrEmpty(this._Name))
            {
                return "No Name";
            }
            else
            {
                return this._Name;
            }
        }
        
        public void SetId(int Id)
        {
            
            if(Id <=0)
            {
                throw new Exception("Student Id cannot be negative");
            }
            this. _id =Id;
        }

        public int GetId()
        {
            return this._id;
        }
    
            
}
public class Program
{
        public static void Main()
        {
            Student s1 = new Student();
            s1.SetId(101);
        s1.SetName("aaaaa");

        Console.WriteLine("Student Id = {0}", s1.GetId());
        Console.WriteLine("Student Name = {0}", s1.GetName());
        Console.WriteLine("Pass Mark = {0}", s1.GetPassMark());
    }
 }

