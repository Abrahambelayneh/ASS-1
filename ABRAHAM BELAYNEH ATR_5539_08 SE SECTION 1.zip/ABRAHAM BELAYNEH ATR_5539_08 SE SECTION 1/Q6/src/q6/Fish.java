/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package q6;

/**
 *
 * @author Abraham
 */
public class Fish extends Animal implements FishInterface{
    
    public void animal(){
        System.out.println("Fish Lives in water.");
    }
    
}
