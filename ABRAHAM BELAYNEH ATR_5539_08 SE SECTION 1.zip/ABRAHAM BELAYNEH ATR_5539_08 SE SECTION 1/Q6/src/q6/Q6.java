/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package q6;

/**
 *
 * @author Abraham
 */
public class Q6 {

    
    public static void main(String[] args) {
        
        Animal value[] = new Animal[3];
        value[0] = new Animal();
        value[1] = new Fish();
        value[2] = new Lion();
        for(int i=0;i<3;i++){
            value[i].animal();
        }
    }
    
}
