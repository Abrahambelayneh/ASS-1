/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package q2;

/**
 *
 * @author Abraham
 */
public class Q2 {

    public static void main(String[] args) {
        
        int x=545;
        int y=485;
        int z=421;
        String val1= "474";
        String val2= "854";
        
        System.out.println(x +" + " + y + "=" +addValues(x,y));
        System.out.println(x +" + " + y + " + " + z + "=" +addValues(x,y,z));
        System.out.println(val1 +" + " + val2 + "=" +addValues(val1,val2));
        
    }
    
    private static int addValues(int int1,int int2){
        int sum=int1+int2;
        return sum;
    }
    
    private static int addValues(int int1, int int2, int int3){
        int sum=int1+int2+int3;
        return sum;
    }
    
    private static int addValues(String value1, String value2){
        
        int int1=Integer.parseInt(value1);
        int int2=Integer.parseInt(value2);
        int sum=int1+int2;
        return sum;
    }
    
}
