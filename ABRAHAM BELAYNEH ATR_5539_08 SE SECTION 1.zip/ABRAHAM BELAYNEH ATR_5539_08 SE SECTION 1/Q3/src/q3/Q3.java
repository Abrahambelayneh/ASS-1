/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package q3;

/**
 *
 * @author Abraham
 */
public class Q3 {
    
    public static void main(String[] args) {
        try{
            int result=45/4;
            System.out.println(result);
        }catch(Exception e){
            e.printStackTrace();
        }
        finally{
            System.out.println("Finally!!!!!");
        }
    }
    
}
